document.getElementById("searchOptions").addEventListener("change", function() {
    var selectBox = document.getElementById("searchTerm");
    var searchOptions = document.getElementById("searchOptions");
    var selectedValue = searchOptions.options[searchOptions.selectedIndex].value;

    // Clear existing options
    selectBox.innerHTML = '';

    // Populate options based on selected value
    if (selectedValue === "scientific") {
        var scientificNames = [
            "Acisoma panorpoides",
            "Acrida exaltata",
            "Acridium melanocorne",
            "Aeolesthes holosericea",
            "Anoplocnemis phasiana",
            "Anoplophora glabripennis",
            "Anoplophora versteegi",
            "Antheraea assamensis",
            "Antheraea proylei",
            "Antilochus coquebertii",
            "Apis cerana indica",
            "Apis dorsata",
            "Apis florea",
            "Apis mellifera",
            "Aplosonyx chalybaeus",
            "Aspongopus nepalensis",
            "Batocera parryi",
            "Batocera roylei",
            "Batocera rubus",
            "Bombyx mori",
            "Brachytrupes orientalis",
            "Chinavia hilaris",
            "Coridius chinensis",
            "Coridius ianus",
            "Coridius singhalanus",
            "Coridius viduatus",
            "Crocothemis servilia",
            "Cybister fembriolatus",
            "Cybister fimbriatus",
            "Cybister limbatus",
            "Cybister sugillatus",
            "Cybister tripunctatus",
            "Cybister ventralis",
            "Cyclopelta siccifolia",
            "Cyrtotrachelus dux",
            "Dalader acuticosta",
            "Dalader planiventris",
            "Darthula hardwickii",
            "Diplacodes trivialis",
            "Diplonychus rusticus",
            "Dundubia intemerata",
            "Dundubia oopaga",
            "Enithares ciliata",
            "Enithares mandalayensis",
            "Erionota torus",
            "Erthesina fullo",
            "Eurostus grossipes",
            "Formica indica",
            "Gryllotalpa orientalis",
            "Gryllus campestris",
            "Halyomorpha picus",
            "Heirodula coarctata",
            "Hieroglyphus banian",
            "Hydrometridae greeni",
            "Hydrometridae greeni(1)",
            "Hydrophilus indicus",
            "Hydrous indicus",
            "Hydrous olivaceous",
            "Laccotrephes maculatus",
            "Lepidiota stigma",
            "Lepidotrigona arcifera",
            "Lethocerus indicus",
            "Lethocerus indicus(1)",
            "Lucanus laminifer",
            "Mantis religiosa",
            "Mecopoda elongata",
            "Melanoplus bivittatus",
            "Meloimorpha cincticornis",
            "Mictis tenebrosa",
            "Neurothemis fulvia",
            "Nezara viridula",
            "Oecophylla smaragdina(1)",
            "Oecophylla smaragdina",
            "Omphisa fuscidentalis",
            "Orthetrum sabina(1)",
            "Orthetrum sabina",
            "Orthetrum triangulare",
            "Orthetrum triangulare(1)",
            "Oryctes rhinoceros",
            "Oxya hyla",
            "Palpopleura sexmaculata",
            "Pantala flavescens",
            "Parapolybia varia",
            "Philosamia ricini",
            "Polistes olivaceus",
            "Polistes stigmata",
            "Potamarcha congener",
            "Prionoxystus robiniae",
            "Pseudagrion microcephalum",
            "Pseudophyllus titan",
            "Rhynchoris humeralis",
            "Rhyothemis variegate",
            "Schizodactylus monstrosa",
            "Solenopsis geminata",
            "Tarbinskiellus portentosus",
            "Tenodera sinensis",
            "Tessaratoma javanica",
            "Tessaratoma quadrata",
            "Tramea basilaris(1)",
            "Tramea basilaris",
            "Udonga montana(1)",
            "Udonga montana",
            "Urothemis signata",
            "Vespa affinis",
            "Vespa auraria",
            "Vespa basalis",
            "Vespa cincta(1)",
            "Vespa cincta",
            "Vespa ducalis",
            "Vespa mandarinia",
            "Vespa orientalis",
            "Vespa soror",
            "Vespa tropica",
            "Vespa tropicana",
            "Vespa vulgaris",
            "Xylocopa violacea(1)",
            "Xylocopa violacea",
            "Xylotrupes gideon"
        ];
        
        
        scientificNames.forEach(function(name) {
            var option = document.createElement("option");
            option.text = name;
            option.value = name; // You can set a value for each option if needed
            selectBox.add(option);
        });
    } else if (selectedValue === "common") {
        var commonNames = [
            "Asian hornet",
    "Backswimmer", "Backswimmer(1)", "Backswimmer(2)",
    "Preying mantis", "Preying mantis(1)", "Preying mantis(2)",
    "Stink bug", "Stink bug(1)", "Stink bug(2)", "Stink bug(3)", "Larger stink bug", "Plant-eating stink bug", "Yellow marmorated stink bug",
    "Pentatomid bug", "Pentatomid bug(1)", "Pentatomid bug(2)",
    "Giant water scavenger", "Giant water scavenger(1)",
    "Short horn grasshopper", "Short horn grasshopper(1)",
    "Yellow-striped locust", "Two striped grasshopper",
    "Green marsh hawk", "Blue chaser", "Fulvous forest skimmer",
    "Coreid bug", "Coreid bug(1)", "Coreid bug(2)", "Coreid bug(3)",
    "Ziireipaopoa",
    "Bush cricket", "Bush cricket(1)",
    "Bug", "Beetle", "Cybister beetle", "Carpenter bee", "Dragonfly(1)", "Dragonfly(2)", "Dragonfly(3)", "Dragonfly(4)", "Dragonfly(5)", "Dragonfly(6)", "Dragonfly(7)", "Dragonfly(8)", "Dragonfly(9)", "Dragonfly(10)", "Dragonfly(11)", "Dragonfly(12)", "Dragonfly(13)",
    "Wasp", "Paper wasp", "Paper wasp(1)", "Paper wasp(2)", "True paper wasp", "Tropical paper wasp", "Lesser paper wasp",
    "Common red ant", "Red Ant",
    "Cicada", "Cicada(1)", "Cicada(2)", "Cicada(3)",
    "Bamboo worm", "Locust borer", "Taro leaf beetle", "Banana skipper", "Banana skipper(1)",
    "Giant water bug", "Giant water bug(1)",
    "Coconut palm rhinoceros beetle", "Long horn beetle", "Limbatus beetle", "Stag beetle", "Stag beetle(1)",
    "Wood ants", "Wood ants(1)",
    "Termite", "Termite(1)", "Termite(2)", "Termite(3)",
    "House cricket", "House cricket(1)", "Field cricket", "Cricket",
    "Coreid Bug", "Coreid bug(1)", "Coreid bug(2)", "Coreid bug(3)",
    "Japanese giant hornet", "Hornet", "Asian widow", "Black tailed hornet", "Yellow jackets",
    "Jewel beetle", "Water beetle", "Water beetle(1)", "Water beetle(2)", "Water beetle(3)", "Water beetle(4)", "True water beetle",
    "Damselfly", "Damselfly(1)",
    "Dragonfly", "Dragonfly(1)", "Dragonfly(2)", "Dragonfly(3)", "Dragonfly(4)", "Dragonfly(5)", "Dragonfly(6)", "Dragonfly(7)", "Dragonfly(8)", "Dragonfly(9)", "Dragonfly(10)", "Dragonfly(11)", "Dragonfly(12)", "Dragonfly(13)",
    "Poly-phagous pest", "Mole cricket", "Water strider", "Water measurer", "Water scavenger", "Water scavenger(1)", "Water scavenger(2)", "Water scorpion", "Water scorpion(1)", "Water scorpion(2)", "Water scorpion(3)",
    "Silkworm", "Mulberry silkworm", "Muga silkworm", "Eri silkworm",
    "Sugarcane white grub"
        ];
        commonNames.forEach(function(name) {
            var option = document.createElement("option");
            option.text = name;
            option.value = name; // You can set a value for each option if needed
            selectBox.add(option);
        });
    }
});


const searchButton = document.getElementById("search-species");

        // Add click event listener to the button
        searchButton.addEventListener("click", function() {
            // Redirect to another HTML file
            window.location.href = "search_species.html"; });