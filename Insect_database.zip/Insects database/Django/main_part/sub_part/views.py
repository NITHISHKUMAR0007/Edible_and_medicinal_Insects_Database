from django.shortcuts import render
from .models import *
from django.conf import settings
from Bio import Entrez, SeqIO
from django.http import JsonResponse, HttpResponse
from Bio.Align.Applications import MuscleCommandline
from io import StringIO
import subprocess
from Bio import Phylo
from Bio.Phylo.TreeConstruction import DistanceCalculator, DistanceTreeConstructor
from Bio import AlignIO
import matplotlib.pyplot as plt
import os
from Bio.Blast import NCBIWWW, NCBIXML
import xml.etree.ElementTree as ET
# Create your views here.
def index(request):
    return render(request,'index.html')
common_name = None
sequence = None
def search(request):
    return render(request,'search.html')

def search_species(request):
    return render(request,'search_species.html')

def data_ncbi(request):
    return render(request,'data_ncbi.html')

def sequenceid(request):
    return render(request,'sequenceid.html')

def tree(request):
    return render(request,'tree.html')

def contact(request):
    return render(request,'contact.html')

def about(request):
    return render(request,'about.html')

def alignment(request):
    return render(request,'alignment.html')


def search_database(request):
    # Define variables outside the if block with default values
    phylum = kingdom = Location = Preparation =Edible_Stage = Purpose = Fats =Fiber = Carbohydrates = Protein= family = genus = species = Class = Reference = Reference2 = Reference3 = None
    global common_name
    if request.method == 'POST':
        common_name = request.POST.get('organism')  # Fetch the selected organism name
        
        try:
            print(common_name)
            taxonomy_entry = Taxonomy.objects.get(Common_name=common_name) 
            phylum = taxonomy_entry.Phylum
            kingdom = taxonomy_entry.Kingdom
            family = taxonomy_entry.Family
            genus = taxonomy_entry.Genus
            species = taxonomy_entry.Species
            Class = taxonomy_entry.Class
            Location=taxonomy_entry.Location
            Preparation=taxonomy_entry.Preparation
            Edible_Stage=taxonomy_entry.Edible_Stage
            Purpose=taxonomy_entry.Purpose
            Protein=taxonomy_entry.Protein
            Fats=taxonomy_entry.Fats
            Fiber=taxonomy_entry.Fiber
            Carbohydrates=taxonomy_entry.Carbohydrates
            Reference =taxonomy_entry.Reference
            Reference2 =taxonomy_entry.Reference2
            Reference3 =taxonomy_entry.Reference3
        except:
            print(common_name)
            taxonomy_entry = Taxonomy.objects.get(Species=common_name) 
            
            phylum = taxonomy_entry.Phylum
            kingdom = taxonomy_entry.Kingdom
            family = taxonomy_entry.Family
            genus = taxonomy_entry.Genus
            species = taxonomy_entry.Species
            Class = taxonomy_entry.Class
            Location=taxonomy_entry.Location
            Preparation=taxonomy_entry.Preparation
            Edible_Stage=taxonomy_entry.Edible_Stage
            Purpose=taxonomy_entry.Purpose
            Protein=taxonomy_entry.Protein
            Fats=taxonomy_entry.Fats
            Fiber=taxonomy_entry.Fiber
            Carbohydrates=taxonomy_entry.Carbohydrates
            Reference =taxonomy_entry.Reference
            Reference2 =taxonomy_entry.Reference2
            Reference3 =taxonomy_entry.Reference3
        

    # Set your email address, and optionally an API key (if required)
    Entrez.email = "your.email@example.com"
    # Entrez.api_key = "your_api_key"  # Uncomment and add your API key if necessary

    # Set your email address, and optionally an API key (if required)
    Entrez.email = "your.email@example.com"
    # Entrez.api_key = "your_api_key"  # Uncomment and add your API key if necessary

    def get_records_for_database(species_name, db):
        search_term = f"{species_name}[Organism]"
        handle = Entrez.esearch(db=db, term=search_term)
        record = Entrez.read(handle)
        return int(record["Count"])

    # Example usage:
    species_name = common_name  # Replace with the species name you are interested in
    
    databases = [
        "pubmed",            # PubMed
        "nuccore",           # Nucleotide Core
        "gene",              # Gene
        "gds",               # Gene Expression Omnibus
        "protein",           # Protein
        "nucleotide",        # Nucleotide
        "taxonomy",          # Taxonomy
        "pcassay",           # PubChem BioAssay
        "structure",         # Structure
        "clinvar",           # ClinVar
        "sra",               # Sequence Read Archive
        "cdd",               # Conserved Domain Database
        "genome",            # Genome
        "mesh"               # Medical Subject Headings
    ]
    
    records_by_database = {}
    for db in databases:
        total_records = get_records_for_database(common_name, db)
        records_by_database[db] = total_records
        print(f"Total records for {common_name} in {db}: {total_records}")

    return render(
        request,
        "search_species.html",
        {
            'phylum': phylum,
            'kingdom': kingdom,
            'family': family,
            'genus': genus,
            'species': species,
            'class': Class,
            'pubmed_records': records_by_database["pubmed"],
            'nuccore_records': records_by_database["nuccore"],
            'gene_records': records_by_database["gene"],
            'gds_records': records_by_database["gds"],
            'protein_records': records_by_database["protein"],
            'nucleotide_records': records_by_database["nucleotide"],
            'taxonomy_records': records_by_database["taxonomy"],
            'pcassay_records': records_by_database["pcassay"],
            'structure_records': records_by_database["structure"],
            'clinvar_records': records_by_database["clinvar"],
            'sra_records': records_by_database["sra"],
            'cdd_records': records_by_database["cdd"],
            'genome_records': records_by_database["genome"],
            'mesh_records': records_by_database["mesh"],
            'Location': Location,
            'Preparation': Preparation,
            'Edible_Stage': Edible_Stage,
            'Purpose': Purpose,
            'Protein': Protein,
            'Fats': Fats,
            'Fiber': Fiber,
            'Carbohydrates': Carbohydrates,
            'common_name': common_name,
        }
    )
def search_data_ncbi(request):
    # Define the common_name variable or fetch it from request.POST or request.GET
    num_data = int(request.POST.get('data_number', 1))
    print(num_data)
    # Function to fetch species information from NCBI
    def get_species_info(species_name):
        # Search NCBI nucleotide database for the species name
        handle = Entrez.esearch(db="nucleotide", term=species_name, retmax=num_data)
        record = Entrez.read(handle)
        handle.close()
        
        # List to store species information
        species_info = []
        
        # Retrieve information for each matching record
        for id in record["IdList"]:
            handle = Entrez.efetch(db="nucleotide", id=id, rettype="gb", retmode="text")
            gb_record = SeqIO.read(handle, "genbank")
            handle.close()

            # Extract accession ID, sequence name, and sequence length
            info = {
                "Accession": gb_record.id,
                "Name": gb_record.description,
                "Base_pair_length": len(gb_record.seq)
            }
            species_info.append(info)

        return species_info
    
    # Call the function to get species information
    species_info = get_species_info(common_name)
    
    # Render the template with the species information
    return render(request, "data_ncbi.html", {"species_info": species_info})    

accession_id= None

def ncbi_sequence(request):
    global sequence
    if request.method == 'POST':
        acc_num = request.POST.get('acc_num')

        # Function to retrieve sequence by accession ID
        def get_sequence_by_accession(accession_id):
            
            Entrez.email = "your@email.com"  # Enter your email here
            handle = Entrez.efetch(db="nucleotide", id=accession_id, rettype="fasta", retmode="text")
            record = handle.read()
            handle.close()
            return record

        # Retrieve sequence based on the provided accession ID
        global accession_id
        accession_id = acc_num
        request.session['accession_id'] = acc_num
        sequence = get_sequence_by_accession(accession_id)
        print(accession_id)
        # Pass the sequence data to the template context
        return render(request, 'sequenceid.html', {'sequence': sequence})
def sequenceid(request):
    id_list = []  # Initialize id_list with an empty list
    
    if 'ids' in request.GET:
        transferred_ids = request.GET.getlist('ids')
        comma_separated_ids = ','.join(transferred_ids)
        id_list = comma_separated_ids.split(',')
        print(id_list)
            
    def fetch_sequence_by_accession(accession_id):
        Entrez.email = "your.email@example.com"  # Set your email address here
        handle = Entrez.efetch(db="nucleotide", id=accession_id, rettype="fasta", retmode="text")
        record = SeqIO.read(handle, "fasta")
        handle.close()
        return record

    def perform_multiple_sequence_alignment(sequences):
        # Write sequences to a temporary file
        temp_file = "temp.fasta"
        SeqIO.write(sequences, temp_file, "fasta")

        # Run MUSCLE for multiple sequence alignment
        muscle_cline = MuscleCommandline(input=temp_file)
        stdout, stderr = muscle_cline()

        # Parse the aligned sequences
        alignment = AlignIO.read(StringIO(stdout), "fasta")

        # Clean up temporary file
        subprocess.call(["rm", temp_file])

        return alignment

    # Example usage:
    accession_ids = id_list
    sequences = [fetch_sequence_by_accession(accession_id) for accession_id in accession_ids]

    aligned_sequences = perform_multiple_sequence_alignment(sequences)

    # Save the aligned sequences to a file
    output_file = "output_alignment.fasta"
    if os.path.exists(output_file):
        os.remove(output_file)
        print(f"Deleted existing file: {output_file}")

    AlignIO.write(aligned_sequences, output_file, "fasta")
    print(f"Aligned sequences saved to {output_file}")

    # Read the alignment file
    alignment = AlignIO.read(output_file, "fasta")

    # Calculate the distance matrix
    calculator = DistanceCalculator('identity')
    distance_matrix = calculator.get_distance(alignment)

    constructor = DistanceTreeConstructor(calculator)
    tree = constructor.build_tree(alignment)

    # Convert the tree to Newick format
    newick_tree = tree.format("newick")
    image_name = "output_tree.png"
    absolute_path = "/home/nithish/Desktop/Insects database/Django/main_part/static/images/" + image_name

    # Delete the existing image if it exists
    if os.path.exists(absolute_path):
        os.remove(absolute_path)
        print(f"Deleted existing image: {image_name}")

    # Draw the tree and save it as PNG
    Phylo.draw(tree, do_show=False)
    plt.savefig(absolute_path)
    print(f"Tree image saved as {absolute_path}")

    # Pass the aligned sequences and tree image path to the template
    return render(request, 'alignment.html',{'alignment': alignment})




def blast_search(request):
    
    def blast_py(accession_id, output_file):
        try:
            # Perform BLAST search
            result_handle = NCBIWWW.qblast("blastn", "nt", accession_id)

            # Check if the output file already exists, delete it if it does
            if os.path.exists(output_file):
                os.remove(output_file)

            # Write results to the specified file
            with open(output_file, "w") as out_handle:
                out_handle.write(result_handle.read())
            
            result_handle.close()
            print("BLAST search results saved to", output_file)
        except Exception as e:
            print("An error occurred:", e)


    # Define the accession_id and output_file
    print(accession_id)  # You need to replace this with your actual accession ID
    output_file = "/home/nithish/Desktop/Insects database/Django/main_part/static/images/my_blast_result.xml"

    blast_py(accession_id, output_file)
    
    # Return an HTTP response (you can modify this as needed)
    return render(request, 'blast_search.html')



def get_sequence_by_accession(accession_id):
    Entrez.email = "your@email.com"  # Enter your email here
    handle = Entrez.efetch(db="nucleotide", id=accession_id, rettype="fasta", retmode="text")
    record = handle.read()
    handle.close()
    return record

# Function to find ORFs in a sequence
def find_orfs(sequence, min_length=100, start_codon='ATG', stop_codons=['TAA', 'TAG', 'TGA']):
    orfs = []
    start_positions = []
    in_orf = False
    current_orf = ''

    for i in range(0, len(sequence), 3):
        codon = sequence[i:i+3]
        if codon == start_codon:
            if not in_orf:
                start_positions.append(i)
                in_orf = True
            current_orf += codon
        elif codon in stop_codons:
            if in_orf:
                if len(current_orf) >= min_length:
                    orfs.append((start_positions[-1], i + 3))
                current_orf = ''
                in_orf = False
        else:
            if in_orf:
                current_orf += codon

    return orfs

def functional_region(request):
    # Example usage: Accession ID for E. coli genome
    # Retrieve genome sequence
    accession_id = request.session.get('accession_id')
    sequence = get_sequence_by_accession(accession_id)

    # Save the sequence to a file named "genome.fa"
    with open("genome.fa", "w") as file:
        file.write(sequence)

    # Load genome sequence
    genome_file = "genome.fa"
    genome_record = SeqIO.read(genome_file, "fasta")
    genome_sequence = genome_record.seq

    # Find ORFs in the genome sequence
    orfs = find_orfs(genome_sequence)

    # Prepare data to pass to the template
    coding_regions = []
    for start, end in orfs:
        coding_regions.append({'start': start, 'end': end, 'length': end - start})

    # Render the template with the data
    return render(request, 'functional_region.html', {'coding_regions': coding_regions})
