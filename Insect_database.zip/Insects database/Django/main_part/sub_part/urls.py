from django.urls import path
from . import views
urlpatterns=[
    path('',views.index,name='index'),
    path('search',views.search,name='search'),
    path('search_species',views.search_species,name='search_species'), 
    path('search_data_ncbi',views.search_data_ncbi,name='search_data_ncbi'),
    path('search_database',views.search_database,name='search_database'),
    path('data_ncbi',views.data_ncbi,name='data_ncbi'),
    path('ncbi_sequence',views.ncbi_sequence,name='ncbi_sequence'),
    path('sequenceid',views.sequenceid,name='sequenceid'),
    path('transfer_ids',views.sequenceid,name='transfer_ids'),
    path('tree',views.tree,name='tree'),
    path('blast_search',views.blast_search,name='blast_search'),
    path('functional_region',views.functional_region,name='functional_region'),
    path('contact',views.contact,name='contact'),
    path('about',views.about,name='about'),
    path('alignment',views.alignment,name='alignment'),
    
]
