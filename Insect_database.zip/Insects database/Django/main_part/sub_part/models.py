from django.db import models

# Create your models here.
class Taxonomy(models.Model):
    Common_name=models.CharField(max_length=50)
    Phylum=models.CharField(max_length=50)
    Class=models.CharField(max_length=50)
    Family=models.CharField(max_length=50)
    Genus=models.CharField(max_length=50)
    Species=models.CharField(max_length=50)
    Kingdom=models.CharField(max_length=50)
    Location=models.CharField(max_length=50)
    Preparation=models.CharField(max_length=255)
    Edible_Stage=models.CharField(max_length=250)
    Purpose=models.CharField(max_length=200)
    Protein=models.CharField(max_length=50)
    Fats=models.CharField(max_length=50)
    Fiber=models.CharField(max_length=50)
    Carbohydrates=models.CharField(max_length=50)
    Reference=models.CharField(max_length=255)
    Reference2=models.CharField(max_length=255)
    Reference3=models.CharField(max_length=255)


